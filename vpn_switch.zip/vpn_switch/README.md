The script to switch Ali cloud eip 
======================================

## Installation

```bash
git clone https://github.com/zzhengyang/vpn_switch.git
pip install tqdm
pip install pxssh
```
## Using

```bash
python ip_switcher.py
```
